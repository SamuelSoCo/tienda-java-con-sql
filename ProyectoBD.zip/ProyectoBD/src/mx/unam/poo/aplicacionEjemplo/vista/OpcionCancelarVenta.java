
package mx.unam.poo.aplicacionEjemplo.vista;


import mx.unam.poo.aplicacionEjemplo.reglasNegocio.CatalogoVentas;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.ReglasNegocioException;

/**
 * Representa la opcion de cancelar la venta actual.
 *
 * @version 1, 18/03/2022
 * @author JCRM
 */
public class OpcionCancelarVenta extends Opcion {

    /**
     * Constructor de OpcionCancelarVenta. Construye una instancia de la opción
     * con sus datos básicos.
     *
     * @param codigo El código de la opción.
     */
    public OpcionCancelarVenta(int codigo) {
        setCodigo(codigo);
        setDescripcion("Cancelar venta actual");
    }

    /**
     * Ejecuta la acción asociada a la opción.
     *
     * @throws OpcionInvalidaException Si la opción no fue ejecutada
     * exitosamente.
     */
    @Override
    public void ejecutarAccion() throws OpcionInvalidaException, ReglasNegocioException {

        if (PuntoDeVenta.getVenta() == null) {
            throw new OpcionInvalidaException("La venta no fue iniciada.");
        }

        try {
            CatalogoVentas catalogo = new CatalogoVentas();
            catalogo.cancelarVenta(PuntoDeVenta.getVenta());
            PuntoDeVenta.setVenta(null);
            System.out.printf("Venta cancelada.%n%n");
        } catch (ReglasNegocioException ex) {
            System.out.println("Error al cancelar la venta actual: " + ex.getMessage());
        }
    }

}
