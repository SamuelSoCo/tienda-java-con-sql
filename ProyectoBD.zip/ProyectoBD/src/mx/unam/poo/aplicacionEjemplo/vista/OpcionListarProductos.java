
package mx.unam.poo.aplicacionEjemplo.vista;


import java.util.List;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.CatalogoProductos;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.Producto;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.ReglasNegocioException;

/**
 * Representa la opción de listar los productos disponibles.
 *
 * @version 1, 18/03/2022
 * @author JCRM
 */
public class OpcionListarProductos extends Opcion {

    /**
     * Constructor de OpcionListarProductos. Construye una instancia de la
     * opción con sus datos básicos.
     *
     * @param codigo El código de la opción.
     */
    public OpcionListarProductos(int codigo) {
        setCodigo(codigo);
        setDescripcion("Listar Productos");
    }

    /**
     * Constructor de OpcionListarProductos. Construye una instancia de la
     * opción vacía.
     *
     */
    public OpcionListarProductos() {
        this(0);
    }

    /**
     * Ejecuta la acción asociada a la opción.
     *
     */
    @Override
    public void ejecutarAccion() {
        try {
            CatalogoProductos catalogo = new CatalogoProductos();
            List<Producto> productos = catalogo.obtenerProductos();

            System.out.printf("Listado de Productos%n");
            System.out.printf("--------------------%n%n");
            System.out.printf("%7s\t%30s\t\t%s%n", "Codigo", "Descripcion", "Precio");
            for (Producto producto : productos) {
                System.out.printf("%7d\t%30s\t\t%f%n", producto.getCodigo(), producto.getDescripcion(),
                        producto.getPrecio());
            }
            System.out.printf("%n%n%n");
        } catch (ReglasNegocioException ex) {
            System.out.print("Error al listar los productos: " + ex.getMessage());
        }
    }

}
