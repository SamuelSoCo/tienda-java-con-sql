
package mx.unam.poo.aplicacionEjemplo.vista;



import mx.unam.poo.aplicacionEjemplo.reglasNegocio.ItemVenta;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.ReglasNegocioException;

/**
 * Clase que representa la opción de listar el carrito de compras.
 * Permite visualizar los productos agregados al carrito con su cantidad y subtotal.
 * 
 * @author JCRM
 */
public class OpcionListarCarrito extends Opcion {

    /**
     * Constructor de OpcionListarCarrito. Construye una instancia de la opción
     * con sus datos básicos.
     *
     * @param codigo El código de la opción.
     */
    public OpcionListarCarrito(int codigo) {
        setCodigo(codigo);
        setDescripcion("Listar Carrito de Compras");
    }

    /**
     * Ejecuta la acción asociada a la opción.
     * Verifica si hay una venta en curso y lista los productos en el carrito.
     *
     * @throws OpcionInvalidaException Si la venta no ha sido iniciada.
     * @throws ReglasNegocioException Si ocurre un error de negocio.
     */
    @Override
    public void ejecutarAccion() throws OpcionInvalidaException, ReglasNegocioException {
        // Verifica si hay una venta en curso.
        if (PuntoDeVenta.getVenta() == null) {
            throw new OpcionInvalidaException("La venta no fue iniciada.");
        }

        // Verifica si el carrito de compras está vacío.
        if (PuntoDeVenta.getVenta().getItems().isEmpty()) {
            System.out.printf("Carrito vacío.%n");
        } else {
            // Imprime el encabezado del carrito de compras.
            System.out.printf("Carrito de Compras%n");
            System.out.printf("------------------%n%n");

            // Imprime el número total de ítems en el carrito.
            System.out.printf("Items: %d%n", PuntoDeVenta.getVenta().getItems().size());
            // Imprime la cabecera de la tabla con los detalles de los ítems.
            System.out.printf("%7s\t%30s\t%9s\t%s%n", "Codigo", "Producto", "Cantidad", "Sub Total");

            // Itera sobre los ítems del carrito y los imprime.
            for (ItemVenta item : PuntoDeVenta.getVenta().getItems()) {
                System.out.printf("%7s\t%30s\t%9s\t%f%n",
                        item.getCodigo(),
                        item.getProducto().getDescripcion(),
                        item.getCantidad(),
                        item.calcularTotal());
            }
        }
    }
}
