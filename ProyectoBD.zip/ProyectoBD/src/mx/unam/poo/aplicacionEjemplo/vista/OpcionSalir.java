
package mx.unam.poo.aplicacionEjemplo.vista;

import mx.unam.poo.aplicacionEjemplo.reglasNegocio.CatalogoVentas;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.ReglasNegocioException;


/**
 *
 * @author jcrm
 */
public class OpcionSalir extends Opcion {

    public OpcionSalir(int codigo) {
        setCodigo(codigo);
        setDescripcion("Salir");
    }

    @Override
    public void ejecutarAccion() {
        try {
            CatalogoVentas catalogo = new CatalogoVentas();
            if (PuntoDeVenta.getVenta() != null) {
                catalogo.cancelarVenta(PuntoDeVenta.getVenta());
            }
            catalogo.cancelarVentasPendientes();
            PuntoDeVenta.Salir();
        } catch (ReglasNegocioException ex) {
            System.out.println("Error al cancelar las ventas : " + ex.getMessage());
        }
    }

}
