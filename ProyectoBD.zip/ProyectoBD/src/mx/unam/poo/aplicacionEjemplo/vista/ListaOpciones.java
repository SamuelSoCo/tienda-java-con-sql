
package mx.unam.poo.aplicacionEjemplo.vista;



import java.util.ArrayList;
import java.util.List;

/**
 * Representa la lista de opciones de la aplicación.
 *
 * @version 1, 18/03/2022
 * @author JCRM
 */
public class ListaOpciones {

    /**
     * La lista de opciones disponibles.
     */
    private static List<Opcion> opciones = new ArrayList<Opcion>();

    /**
     * Construye estáticamente la lista de opciones.
     */
    static {
        opciones.add(new OpcionListarProductos(1));
        opciones.add(new OpcionIniciarVenta(2));
        opciones.add(new OpcionAgregarItemVenta(3));
        opciones.add(new OpcionListarCarrito(4));
        opciones.add(new OpcionConfirmarVenta(5));
        opciones.add(new OpcionCancelarVenta(6));
        opciones.add(new OpcionSalir(99));
    }

    /**
     * Obtiene el listado de opciones disponibles.
     *
     * @return El listado de opciones.
     */
    public static List<Opcion> obtenerOpciones() {
        return opciones;
    }

    /**
     * Permite obtener una opción según su código.
     *
     * @param codigo El código de la opción.
     * @return La opción encontrada.
     * @throws OpcionInvalidaException Si la opción no existe.
     */
    public static Opcion obtener(int codigo) throws OpcionInvalidaException {
        Opcion opcion = null;
        for (Opcion o : opciones) {
            if (o.getCodigo() == codigo) {
                opcion = o;
                break;
            }
        }

        if (opcion == null) {
            throw new OpcionInvalidaException("Opción inválida.");
        }

        return opcion;
    }
}
