
package mx.unam.poo.aplicacionEjemplo.vista;



import mx.unam.poo.aplicacionEjemplo.reglasNegocio.CatalogoVentas;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.ReglasNegocioException;

public class OpcionIniciarVenta extends Opcion {

    /**
     * Constructor de OpcionIniciarVenta. Construye una instancia de la opción
     * con sus datos básicos.
     *
     * @param codigo El código de la opción.
     */
    public OpcionIniciarVenta(int codigo) {
        setCodigo(codigo);
        setDescripcion("Iniciar Venta");
    }

    /**
     * Ejecuta la acción asociada a la opción.
     *
     * @throws OpcionInvalidaException Si la opción no fue ejecutada
     * exitosamente.
     */
    @Override
    public void ejecutarAccion() throws OpcionInvalidaException, ReglasNegocioException {
        if (PuntoDeVenta.getVenta() != null) {
            throw new OpcionInvalidaException("La venta ya fue iniciada.");
        }

        CatalogoVentas catalogo = new CatalogoVentas();
        PuntoDeVenta.setVenta(catalogo.iniciarVenta());
        System.out.printf("Venta iniciada.%n");
    }
}
