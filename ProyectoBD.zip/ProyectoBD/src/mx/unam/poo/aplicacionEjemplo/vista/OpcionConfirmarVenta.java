
package mx.unam.poo.aplicacionEjemplo.vista;



import mx.unam.poo.aplicacionEjemplo.reglasNegocio.CatalogoVentas;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.ReglasNegocioException;


import mx.unam.poo.aplicacionEjemplo.reglasNegocio.CatalogoVentas;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.ReglasNegocioException;

/**
 * Representa la opción de finalizar una venta.
 *
 * @version 1, 18/03/2022
 * @author JCRM
 */
public class OpcionConfirmarVenta extends Opcion {

    /**
     * Constructor de OpcionConfirmarVenta. Construye una instancia de la opción
     * con sus datos básicos.
     *
     * @param codigo El código de la opción.
     */
    public OpcionConfirmarVenta(int codigo) {
        setCodigo(codigo);
        setDescripcion("Confirmar Venta Actual");
    }

    /**
     * Ejecuta la acción asociada a la opción.
     *
     * @throws OpcionInvalidaException Si la opción no fue ejecutada
     * exitosamente.
     */
    @Override
    public void ejecutarAccion() throws OpcionInvalidaException, ReglasNegocioException {
        if (PuntoDeVenta.getVenta() == null) {
            throw new OpcionInvalidaException("La venta no fue iniciada.");
        }

        try {
            CatalogoVentas catalogo = new CatalogoVentas();
            catalogo.confirmarVenta(PuntoDeVenta.getVenta());
            System.out.printf("Venta confirmada.\nTotal: %f%n%n", PuntoDeVenta.getVenta().total());
            PuntoDeVenta.setVenta(null);
        } catch (ReglasNegocioException ex) {
            System.out.println("Error al finalizar la venta: " + ex.getMessage());
        }
    }

}
