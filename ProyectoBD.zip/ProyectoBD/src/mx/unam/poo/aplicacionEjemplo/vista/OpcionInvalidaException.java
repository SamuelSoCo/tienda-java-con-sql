
package mx.unam.poo.aplicacionEjemplo.vista;


/**
 *
 * @author jcrm
 */
public class OpcionInvalidaException extends Exception {

    public OpcionInvalidaException(String mensaje) {
        super(mensaje);
    }
}
