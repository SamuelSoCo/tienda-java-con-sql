
package mx.unam.poo.aplicacionEjemplo.vista;


import java.util.InputMismatchException;
import java.util.Scanner;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.CatalogoProductos;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.ItemVenta;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.Producto;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.ReglasNegocioException;

/**
 *  Representa la opción de agregar un ítem de venta a una venta iniciada.
 *
 * @version 1, 18/03/2022
 * @author JCRM
 */
public class OpcionAgregarItemVenta extends Opcion {

    /**
     * Constructor de OpcionAgregarItemVenta. Construye una instancia de la
     * opción con sus datos básicos.
     *
     * @param codigo El código de la opción.
     */
    public OpcionAgregarItemVenta(int codigo) {
        setCodigo(codigo);
        setDescripcion("Agregar un Item de Venta");
    }



    /**
     * Ejecuta la acción asociada a la opción.
     *
     * @throws OpcionInvalidaException Si la opción no fue ejecutada
     * exitosamente.
     */
    @Override
    public void ejecutarAccion() throws OpcionInvalidaException {
        Scanner lector = new Scanner(System.in);

        if (PuntoDeVenta.getVenta() == null) {
            throw new OpcionInvalidaException("La venta no fue iniciada.");
        }

        try {
            new OpcionListarProductos().ejecutarAccion();

            CatalogoProductos catalogoProd = new CatalogoProductos();
            Producto producto = null;
            System.out.print("Seleccione un Producto de la lista a agregar: ");
            try {
                int idProducto = lector.nextInt();
                producto = catalogoProd.obtenerProducto(idProducto);
                if (producto == null) {
                    throw new OpcionInvalidaException("Producto inválido.");
                }
            } catch (InputMismatchException ex) {
                throw new OpcionInvalidaException("Número inválido !");
            }

            int cantidad = 0;
            System.out.print("Seleccione la cantidad a agregar: ");
            try {
                cantidad = lector.nextInt();
            } catch (InputMismatchException ex) {
                throw new OpcionInvalidaException("Cantidad inválida !");
            }

            PuntoDeVenta.getVenta().agregarItem(new ItemVenta(producto, cantidad));

            clearConsole();
            System.out.printf("Agregados %d unidades del producto %s.%n", cantidad, producto.getDescripcion());

        } catch (ReglasNegocioException ex) {
            clearConsole();
            System.out.println("Error al agregar un ítem a la venta actual: " + ex.getMessage());
        } catch (OpcionInvalidaException ex) {
            clearConsole();
            System.out.println(ex.getMessage());
        } catch (Exception ex) {
            clearConsole();
            System.out.println("Error al agregar un ítem a la venta actual.");
        }
    }
    
        public final static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                Runtime.getRuntime().exec("cls");
            } else {
                Runtime.getRuntime().exec("clear");
            }
        } catch (final Exception e) { // Handle any exceptions. } }

        }
    }
}
