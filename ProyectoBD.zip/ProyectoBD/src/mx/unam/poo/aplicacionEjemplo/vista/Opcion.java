
package mx.unam.poo.aplicacionEjemplo.vista;


public abstract class Opcion {

    private int codigo = 0;
    private String descripcion;

    public abstract void ejecutarAccion() throws Exception;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

}
