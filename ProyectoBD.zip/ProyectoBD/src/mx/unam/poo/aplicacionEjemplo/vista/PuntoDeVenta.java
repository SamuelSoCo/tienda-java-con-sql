package mx.unam.poo.aplicacionEjemplo.vista;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import mx.unam.poo.aplicacionEjemplo.reglasNegocio.Venta;

public class PuntoDeVenta {

    private static boolean SALIR = false;
    private static Venta venta = null;

    public static Venta getVenta() {
        return venta;
    }

    public static void setVenta(Venta venta) {
        PuntoDeVenta.venta = venta;
    }

    public void iniciar() {
        while (!PuntoDeVenta.SALIR) {
            int opcionSeleccionada = mostrarMenu();
            try {
                Opcion opcion = ListaOpciones.obtener(opcionSeleccionada);
                opcion.ejecutarAccion();
            } catch (Exception ex) {
                System.out.println(ex.getMessage() + "\n");
            }
            //iniciar();
        }
    }
    
   public  static void Salir() {
            SALIR = true;
        }
   
    public static void main(String[] args) {
            PuntoDeVenta p = new PuntoDeVenta();
            p.iniciar();
        }

    private int mostrarMenu() {
        Scanner lector = new Scanner(System.in);
        mostrarVentaActual();

        System.out.println("Opciones");
        System.out.println("--------\n");

        List<Opcion> opciones = ListaOpciones.obtenerOpciones();
        for (Opcion opcion : opciones) {
            System.out.printf("%d - %s%n", opcion.getCodigo(), opcion.getDescripcion());
        }

        System.out.printf("%nOpción: ");
        int opcionSeleccionada = 0;
        try {
            opcionSeleccionada = lector.nextInt();
        } catch (InputMismatchException ex) {
            clearConsole();
             System.out.print("\f");
            System.out.printf("Opción Inválida !!%n");
            mostrarMenu();
        }
        System.out.print("\f");
        //clearConsole();
        return opcionSeleccionada;
    }

    private void mostrarVentaActual() {
        if (PuntoDeVenta.getVenta() != null) {
            System.out.printf("Venta Actual: Codigo Venta: %d - Total: %f%n%n",
                    PuntoDeVenta.getVenta().getCodigo(),
                    PuntoDeVenta.getVenta().total());
        }
    }

    public final static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                Runtime.getRuntime().exec("cls");
            } else {
                Runtime.getRuntime().exec("clear");
            }
        } catch (final Exception e) { // Handle any exceptions. } }

        }
    }
}
