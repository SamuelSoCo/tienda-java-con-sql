
package mx.unam.poo.aplicacionEjemplo.accesoDatos;


/**
 * Representa un error de acceso a la base de datos.
 *
 * @version 1, 18/03/2022
 * @author JCRM
 */
public class BaseDatosException extends Exception {

    /**
     * Constructor de BaseDatosException. Construye una instancia en base a un
     * mensaje de error.
     *
     * @param message El mensaje de error.
     */
    public BaseDatosException(String message) {
        super(message);
    }

    /**
     * Constructor de BaseDatosException. Construye una instancia en base a un
     * mensaje de error y la excepción original.
     *
     * @param message El mensaje de error.
     * @param original La excepción original.
     */
    public BaseDatosException(String message, Throwable original) {
        super(message, original);
    }

}
