
package mx.unam.poo.aplicacionEjemplo.accesoDatos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Representa la base de datos en el sistema. Ofrece los métodos de acceso a la
 * misma.
 *
 * @version 1, 18/03/2022
 * @author JCRM
 */
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BaseDatos {

    private static final String DATABASE_URL = "jdbc:mysql://localhost:3307/puntoVenta";
    private static final String NOMBREUSUARIO = "root";
    private static final String CONTRASENIA = "samuel";
    private Connection conexion;
    private PreparedStatement ps;

    /**
     * Constructor de BaseDatos. Crea una instancia del acceso a la base de
     * datos.
     */
    public BaseDatos() {
    }

    /**
     * Se conecta con la base de datos.
     *
     * @throws BaseDatosException Si existe un error al conectarse.
     */
    private void conectarBD() throws BaseDatosException {
        try {
            if (conexion != null && !conexion.isClosed()) {
                throw new BaseDatosException("La conexión ya se encuentra abierta.");
            } else {
                conexion = DriverManager.getConnection(DATABASE_URL, NOMBREUSUARIO, CONTRASENIA);
            }
        } catch (SQLException ex) {
            throw new BaseDatosException("Error al conectarse a la base de datos.", ex);
        }
    }

    /**
     * Permite desconectarse de la base de datos.
     *
     * @throws BaseDatosException Si existe un error al desconectarse.
     */
    private void desconectarBD() throws BaseDatosException {
        try {
            if (conexion == null || conexion.isClosed()) {
                throw new BaseDatosException("La conexión ya se encuentra cerrada.");
            } else {
                conexion.close();
            }
        } catch (SQLException ex) {
            throw new BaseDatosException("Error al desconectarse de la base de datos.", ex);
        }
    }

    /**
     * Crea una consulta en base a una sentencia SQL
     *
     * @param sentenciaSQL La sentencia SQL.
     * @throws BaseDatosException En caso de que marque error la BD
     */
    public void crearConsultaParametros(String sentenciaSQL) throws BaseDatosException {
        try {
            conectarBD();
            ps = conexion.prepareStatement(sentenciaSQL);
        } catch (BaseDatosException | SQLException ex) {
            throw new BaseDatosException("Error al crear la consulta.", ex);
        }
    }

    /**
     * Asigna un parámetro de tipo cadena a la consulta creada.
     *
     * @param indice El índice del parámetro.
     * @param valor El valor del parámetro.
     * @throws BaseDatosException En caso de que marque error la BD
     */
    public void asignarParametroCadena(int indice, String valor) throws BaseDatosException {
        try {
            ps.setString(indice, valor);
        } catch (SQLException ex) {
            throw new BaseDatosException("Error al asignar el parámetro de cadena.", ex);
        }
    }

    /**
     * Asigna un parámetro de tipo entero a la consulta creada.
     *
     * @param indice El índice del parámetro.
     * @param valor El valor del parámetro.
     * @throws BaseDatosException En caso de que marque error la BD
     */
    public void asignarParametroEntero(int indice, int valor) throws BaseDatosException {
        try {
            ps.setInt(indice, valor);
        } catch (SQLException ex) {
            throw new BaseDatosException("Error al asignar el parámetro entero.", ex);
        }
    }

    /**
     * Asigna un parámetro de tipo fecha a la consulta creada.
     *
     * @param indice El índice del parámetro.
     * @param valor El valor del parámetro.
     * @throws BaseDatosException En caso de que marque error la BD
     */
    public void asignarParametroFecha(int indice, Date valor) throws BaseDatosException {
        try {
            ps.setDate(indice, valor);
        } catch (SQLException ex) {
            throw new BaseDatosException("Error al asignar el parámetro de fecha.", ex);
        }
    }

    /**
     * Ejecuta la consulta creada y retorna el resultado de la consulta.
     *
     * @return El resultado de la consulta.
     * @throws BaseDatosException Si ocurre un error al ejecutar el comando
     */
    public List<Map<String, Object>> ejecutarConsultaParametros() throws BaseDatosException {
        List<Map<String, Object>> datos = new ArrayList<>();
        try (ResultSet conjuntoResultados = ps.executeQuery()) {
            ResultSetMetaData metaData = conjuntoResultados.getMetaData();
            int numeroColumnas = metaData.getColumnCount();

            while (conjuntoResultados.next()) {
                Map<String, Object> fila = new HashMap<>();
                for (int i = 1; i <= numeroColumnas; i++) {
                    fila.put(metaData.getColumnName(i), conjuntoResultados.getObject(i));
                }
                datos.add(fila);
            }
            ps.close();
            desconectarBD();

        } catch (SQLException ex) {
            throw new BaseDatosException("Error al ejecutar la consulta con parámetros.", ex);
        }
        return datos;
    }

    /**
     * Ejecuta la consulta especificada y retorna el resultado de la consulta.
     *
     * @param consulta la consulta SQL
     * @return El resultado de la consulta.
     * @throws BaseDatosException Si ocurre un error al ejecutar el comando
     */
    public List<Map<String, Object>> ejecutarConsulta(String consulta) throws BaseDatosException {
        List<Map<String, Object>> datos = new ArrayList<>();

        try (Connection conexion = DriverManager.getConnection(DATABASE_URL, NOMBREUSUARIO, CONTRASENIA);
             Statement instruccion = conexion.createStatement();
             ResultSet conjuntoResultados = instruccion.executeQuery(consulta)) {

            ResultSetMetaData metaData = conjuntoResultados.getMetaData();
            int numeroColumnas = metaData.getColumnCount();

            while (conjuntoResultados.next()) {
                Map<String, Object> fila = new HashMap<>();
                for (int i = 1; i <= numeroColumnas; i++) {
                    fila.put(metaData.getColumnName(i), conjuntoResultados.getObject(i));
                }
                datos.add(fila);
            }

        } catch (SQLException ex) {
            throw new BaseDatosException("Error al ejecutar la consulta.", ex);
        }

        return datos;
    }

    /**
     * Ejecuta la consulta creada y retorna un escalar
     *
     * @return El escalar que es el resultado de la consulta.
     * @throws BaseDatosException Si ocurre un error al ejecutar el comando
     */
    public int ejecutarEscalar() throws BaseDatosException {
        int escalar = 0;
        try (ResultSet datos = ps.executeQuery()) {
            if (datos.next()) {
                escalar = datos.getInt(1);
            }
            datos.close();
            ps.close();
            desconectarBD();
        } catch (ClassCastException | SQLException ex) {
            throw new BaseDatosException("Error al ejecutar un escalar.", ex);
        }

        return escalar;
    }

    /**
     * Ejecuta la consulta creada (DDL) y regresa el id generado
     *
     * @param query La consulta SQL DDL.
     * @return El id que se genera al ejecutar la consulta
     * @throws BaseDatosException Si ocurre un error al ejecutar el comando
     */
    public int ejecutarDDLWithID(String query) throws BaseDatosException {
        int id = -1;
        try {
            conectarBD();
            try (Statement st = conexion.createStatement()) {
                st.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
                try (ResultSet rs = st.getGeneratedKeys()) {
                    if (rs.next()) {
                        id = rs.getInt(1);
                    }
                }
            }
            desconectarBD();
        } catch (ClassCastException | SQLException ex) {
            throw new BaseDatosException("Error al ejecutar un escalar.", ex);
        }
        return id;
    }

    public static void main(String[] args) {
        BaseDatos bd = new BaseDatos();
        try {
            List<Map<String, Object>> datos = bd.ejecutarConsulta("select * from productos");
            for (Map<String, Object> fila : datos) {
                for (Map.Entry<String, Object> entry : fila.entrySet()) {
                    System.out.printf("%13s%27s%3s", entry.getKey() + ":", entry.getValue(), "");
                }
                System.out.println("");
            }
        } catch (BaseDatosException ex) {
            Logger.getLogger(BaseDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
