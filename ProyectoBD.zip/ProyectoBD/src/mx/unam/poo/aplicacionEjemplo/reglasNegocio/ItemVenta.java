
package mx.unam.poo.aplicacionEjemplo.reglasNegocio;


public class ItemVenta {

    private int codigo;
    private Producto producto;
    private int cantidad;

    
    /**
     * Constructor de ItemVenta. Construye una instancia del ítem completo
     *
     * @param codigo El código del producto.
     * @param producto El producto asociado.
     * @param cantidad La cantidad de unidades del producto.
     */
    public ItemVenta(int codigo, Producto producto, int cantidad) {
        this.codigo = codigo;
        this.producto = producto;
        this.cantidad = cantidad;
    }

        /**
     * Constructor de ItemVenta. Construye una instancia del ítem con los datos básicos.
     *
     * @param producto El producto asociado.
     * @param cantidad La cantidad de unidades del producto.
     */
    public ItemVenta(Producto producto, int cantidad) {
        this(0, producto, cantidad);
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        if (codigo <= 0) {
            throw new IllegalArgumentException("El código es inválido.");
        }
        this.codigo = codigo;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        if (producto == null) {
            throw new IllegalArgumentException("El producto no puede ser nulo.");
        }
        this.producto = producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad es inválida.");
        }
        this.cantidad = cantidad;
    }

    public double calcularTotal() {
        return producto.getPrecio() * cantidad;
    }

}
