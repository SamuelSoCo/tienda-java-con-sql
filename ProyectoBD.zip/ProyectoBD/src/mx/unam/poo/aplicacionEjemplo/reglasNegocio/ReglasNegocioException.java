
package mx.unam.poo.aplicacionEjemplo.reglasNegocio;

/**
 *
 * @author jcrm
 */
public class ReglasNegocioException extends Exception {


    public ReglasNegocioException(String mensaje, Throwable thrown) {
        super(thrown);
    }

    public ReglasNegocioException(String s) {
        super(s);
    }
}
    