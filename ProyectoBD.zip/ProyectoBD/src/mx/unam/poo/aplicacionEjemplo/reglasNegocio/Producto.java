
package mx.unam.poo.aplicacionEjemplo.reglasNegocio;


/**
 * Representa un producto genérico.
 *
 * @version 1, 18/03/2022
 * @author JCRM
 */
public class Producto {

    private int codigo;
    private String descripcion;
    private double precio;

    /**
     * Constructor de Producto. Construye una instancia del producto con sus
     * datos completos.
     *
     * @param codigo El código del producto.
     * @param descripcion La descripción del producto.
     * @param precio El precio del producto.
     */
    public Producto(int codigo, String descripcion, double precio) {
        setCodigo(codigo);
        setPrecio(precio);
        setDescripcion(descripcion);
    }

    /**
     * Obtiene el precio
     *
     * @return Un valor double especificando el precio.
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * Establece el precio
     *
     * @param precio El precio del producto.
     * @throws IllegalArgumentException En caso de que el precio sea menor a 0
     */
    public void setPrecio(double precio) {
        if (precio < 0) {
            throw new IllegalArgumentException("El precio es inválido.");
        }
        this.precio = precio;
    }

    /**
     * Obtiene el codigo
     *
     * @return Un valor int especificando el codigo.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Establece el codigo
     *
     * @param codigo El código del producto.
     * @throws IllegalArgumentException En caso de que el codigo sea menor a 0
     */
    public void setCodigo(int codigo) {
        if (codigo < 0) {
            throw new IllegalArgumentException("El codigo es inválido.");
        }
        this.codigo = codigo;
    }

    /**
     * Obtiene la descripcion
     *
     * @return Una cadena especificando la descripcion.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Establece la descripcion
     *
     * @param descripcion La descripción del producto.
     * @throws IllegalArgumentException En caso de que la descripcion sea cadena
     * vacia.
     */
    public void setDescripcion(String descripcion) {
        if (descripcion.isEmpty()) {
            throw new IllegalArgumentException("La descripción es inválida.");
        }
        this.descripcion = descripcion;
    }

}
