
package mx.unam.poo.aplicacionEjemplo.reglasNegocio;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import mx.unam.poo.aplicacionEjemplo.accesoDatos.BaseDatos;
import mx.unam.poo.aplicacionEjemplo.accesoDatos.BaseDatosException;

/**
 * Representa el catálogo de productos del sistema.
 *
 * @version 1, 18/03/2022
 * @author JCRM
 */
public class CatalogoVentas {

    /**
     * Obtiene el listado de ventas registradas en el sistema.
     *
     * @return El listado de ventas registradas.
     * @throws ReglasNegocioException Si ocurre un error de negocio.
     */
    public List<Venta> obtenerVentas() throws ReglasNegocioException {
        List<Venta> ventas = new ArrayList<Venta>();

        try {
            String sql = "SELECT codigo, fecha FROM ventas";
            BaseDatos db = new BaseDatos();

            List datosVentas = db.ejecutarConsulta(sql);
            Iterator<Map> iterador = datosVentas.iterator();

            Venta venta = null;
            while (iterador.hasNext()) {
                try {
                    venta = new Venta();
                    Map item = iterador.next();
                    venta.setCodigo((Integer) item.get("codigo"));
                    venta.setFecha((LocalDateTime) item.get("fecha"));

                    List<ItemVenta> items = obtenerItemsVenta(venta);
                    for (ItemVenta reg : items) {
                        venta.agregarItem(reg);
                    }

                    ventas.add(venta);
                } catch (ClassCastException ex) {
                    throw new ReglasNegocioException("Los tipos no coinciden.", ex);
                }
            }
        } catch (BaseDatosException ex) {
            throw new ReglasNegocioException("Error al acceder a la base de datos para obtener las ventas.");
        } catch (ReglasNegocioException ex) {
            throw new ReglasNegocioException("Error a obtener las ventas. " + ex.getMessage());
        }
        return ventas;
    }

    /**
     * Obtiene los ítems de una venta.
     *
     * @param venta La venta cuyos ítems se van a obtener.
     * @return Los ítems de la venta.
     * @throws ReglasNegocioException Si ocurre un error de negocio.
     */
    private List<ItemVenta> obtenerItemsVenta(Venta venta) throws ReglasNegocioException {
        List<ItemVenta> items = new ArrayList<ItemVenta>();

        try {
            String sql = "SELECT codigo, cantidad, codigoProducto FROM itemsVenta WHERE codigoVenta = ?";
            BaseDatos db = new BaseDatos();
            db.crearConsultaParametros(sql);
            db.asignarParametroEntero(1, venta.getCodigo());
            List datosItems = db.ejecutarConsultaParametros();
            Iterator<Map> iterador = datosItems.iterator();
            ItemVenta item = null;
            CatalogoProductos catalogoProd = new CatalogoProductos();

            while (iterador.hasNext()) {
                try {
                    Map reg = iterador.next();
                    Producto producto = catalogoProd.obtenerProducto((Integer) reg.get("codigo"));
                    item = new ItemVenta((Integer) reg.get("codigoProducto"), producto, (Integer) reg.get("cantidad"));

                    venta.agregarItem(item);
                } catch (ClassCastException ex) {
                    throw new ReglasNegocioException("Los tipos no coinciden.", ex);
                }
            }

        } catch (BaseDatosException ex) {
            throw new ReglasNegocioException("Error al acceder a la base de datos para obtener los ítems de venta.");
        } catch (ReglasNegocioException ex) {
            throw new ReglasNegocioException("Error a obtener los ítems de venta. " + ex.getMessage());
        }

        return items;
    }

    /**
     * Confirma una venta registrando sus ítems en el sistema. La venta debe
     * poseer items.
     *
     * @param venta La venta a registrar.
     * @throws ReglasNegocioException Si ocurre un error de negocio.
     */
    public void confirmarVenta(Venta venta) throws ReglasNegocioException {
        if (venta.getItems().size() == 0) {
            throw new ReglasNegocioException("La venta no contiene ningún ítem.");
        }

        BaseDatos db = new BaseDatos();
        try {

            String sql = "INSERT INTO itemsVenta (codigoVenta, codigoProducto, cantidad) VALUES (?, ?, ?);";
            for (ItemVenta item : venta.getItems()) {
                db.crearConsultaParametros(sql);
                db.asignarParametroEntero(1, venta.getCodigo());
                db.asignarParametroEntero(2, item.getProducto().getCodigo());
                db.asignarParametroEntero(3, item.getCantidad());
                db.ejecutarConsultaParametros();
            }
        } catch (BaseDatosException ex) {
            throw new ReglasNegocioException("Error al registrar la venta.", ex);
        }
    }

    /**
     * Inicia una nueva venta en el sistema.
     *
     * @return La venta iniciada.
     * @throws ReglasNegocioException Si ocurre un error de negocio.
     */
    public Venta iniciarVenta() throws ReglasNegocioException {
        Venta venta = new Venta();
        BaseDatos db = new BaseDatos();
        try {
            String sql = "INSERT INTO ventas  VALUES ();";
            int id = db.ejecutarDDLWithID(sql);
            venta.setCodigo(id);
        } catch (BaseDatosException ex) {
            throw new ReglasNegocioException("Error al iniciar la venta.", ex);
        }
        return venta;
    }

    /**
     * Cancela las ventas pendientes (iniciadas pero que no poseen ítems).
     *
     * @throws ReglasNegocioException Si ocurre un error de negocio.
     */
    public void cancelarVentasPendientes() throws ReglasNegocioException {
        try {
            List<Venta> ventas = obtenerVentas();

            for (Venta venta : ventas) {
                if (venta.getItems().isEmpty()) {
                    cancelarVenta(venta);
                }
            }
        } catch (Exception ex) {
            throw new ReglasNegocioException("Error al cancelar las ventas vacías.", ex);
        }
    }

    /**
     * Cancela una venta.
     *
     * @param venta La venta a cancelar.
     * @throws ReglasNegocioException Si ocurre un error de negocio.
     */
    public void cancelarVenta(Venta venta) throws ReglasNegocioException {
        BaseDatos db = new BaseDatos();
        try {

            String sql = "DELETE itemsVenta WHERE codigo = ?";
            for (ItemVenta item : venta.getItems()) {
                db.crearConsultaParametros(sql);
                db.asignarParametroEntero(1, item.getCodigo());
                db.ejecutarConsultaParametros();
            }

            sql = "DELETE Ventas WHERE Codigo = ?";
            db.crearConsultaParametros(sql);
            db.asignarParametroEntero(1, venta.getCodigo());
            db.ejecutarConsultaParametros();

        } catch (BaseDatosException ex) {
            throw new ReglasNegocioException("Error al cancelar la venta.", ex);
        }
    }

}
