
package mx.unam.poo.aplicacionEjemplo.reglasNegocio;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import mx.unam.poo.aplicacionEjemplo.accesoDatos.BaseDatos;
import mx.unam.poo.aplicacionEjemplo.accesoDatos.BaseDatosException;

/**
 * Representa el catálogo de productos del sistema.
 *
 * @version 1, 18/03/2022
 * @author JCRM
 */
public class CatalogoProductos {

    /**
     * Obtiene la lista de productos del sistema.
     *
     * @return Una lista de productos.
     * @throws ReglasNegocioException Si ocurre un error de negocio.
     */
    public List<Producto> obtenerProductos() throws ReglasNegocioException {
        List<Producto> productos = new ArrayList<Producto>();
        try {
            String sql = "SELECT codigo, descripcion, precio FROM productos";
            BaseDatos db = new BaseDatos();
            List datos = db.ejecutarConsulta(sql);
            Iterator<Map> iterador = datos.iterator();

            Producto p = null;
            while (iterador.hasNext()) {
                try {
                    Map item = iterador.next();
                    p = new Producto((Integer) item.get("codigo"), item.get("descripcion").toString(), (Float) item.get("precio"));
                    productos.add(p);
                } catch (ClassCastException ex) {
                    throw new ReglasNegocioException("Los tipos no coinciden.", ex);
                }
            }

        } catch (BaseDatosException ex) {
            throw new ReglasNegocioException("Error al acceder a la base de datos para obtener los productos.");
        } catch (ReglasNegocioException ex) {
            throw new ReglasNegocioException("Error a obtener los productos.");
        }

        return productos;
    }

    /**
     * Obtiene un producto en base a su código.
     *
     * @param codigo El código del producto.
     * @return El producto encontrado.
     * @throws ReglasNegocioException Si ocurre un error de negocio.
     */
    public Producto obtenerProducto(int codigo) throws ReglasNegocioException {
        Producto producto = null;

        try {
            if (codigo <= 0) {
                throw new ReglasNegocioException("El código es inválido.");
            }

            String sql = "SELECT codigo, descripcion, precio FROM productos WHERE codigo = ?";
            BaseDatos db = new BaseDatos();
            db.crearConsultaParametros(sql);
            db.asignarParametroEntero(1, codigo);
            List datos = db.ejecutarConsultaParametros();
            Iterator<Map> iterador = datos.iterator();

            while (iterador.hasNext()) {
                try {
                    Map item = iterador.next();
                    producto = new Producto((Integer) item.get("codigo"), item.get("descripcion").toString(), (Float) item.get("precio"));
                } catch (ClassCastException ex) {
                    throw new ReglasNegocioException("Los tipos no coinciden.", ex);
                }
            }
        } catch (BaseDatosException ex) {
            throw new ReglasNegocioException("Error al acceder a la base de datos para obtener los productos.");
        } catch (ReglasNegocioException ex) {
            throw new ReglasNegocioException("Error a obtener los productos. " + ex.getMessage());
        }

        return producto;
    }

}
