
package mx.unam.poo.aplicacionEjemplo.reglasNegocio;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jcrm
 */
public class Venta {

    private int codigo;
    private LocalDateTime fecha;
    private List<ItemVenta> items;

    public Venta() {
        this.codigo = 0;
        this.fecha = LocalDateTime.MAX;
        this.items = new ArrayList<ItemVenta>();
    }

    public double total() {
        double total = 0f;
        for (ItemVenta item : items) {
            total += item.calcularTotal();
        }
        return total;
    }

    public void agregarItem(ItemVenta item) {
        if (item == null || item.getProducto() == null || item.getCantidad() == 0) {
            throw new IllegalArgumentException("El ítem es inválido.");
        }
        items.add(item);
    }

    public List<ItemVenta> getItems() {
        return items;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        if (codigo <= 0) {
            throw new IllegalArgumentException("El código es inválido.");
        }
        this.codigo = codigo;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

}
